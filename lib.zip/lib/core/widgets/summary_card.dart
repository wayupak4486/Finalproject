import 'package:flutter/material.dart';

class SummaryCard extends StatelessWidget {
  const SummaryCard({
    required this.icon,
    required this.title,
    required this.value,
    super.key,
  });

  final IconData icon;
  final String title;
  final String value;

  //การ์ดเทา หน้าสถิติ
  static const double iconSize = 28; // ขนาดไอคอน
  static const double valueFontSize = 22; // ตัวเลขใหญ่
  static const double titleFontSize = 18; // ข้อความเล็ก
  static const double cardPadding = 16; // ระยะห่างขอบในการ์ด

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(cardPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: colorScheme.primary, size: iconSize),
            const SizedBox(height: 12),
            Text(
              value,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                fontSize: valueFontSize,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(fontSize: titleFontSize),
            ),
          ],
        ),
      ),
    );
  }
}
