import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/utils/number_formatter.dart';
import '../../../../services/price_source/wongpanit_price_service.dart';
import '../../data/models/material_price_model.dart';

class PriceStyle {
  PriceStyle._();

  // ---------- ส่วนที่ 1: แถบชื่อหน้าจอ (AppBar) ----------
  static const double? appBarTitleFontSize =
      null; // ตัวหนังสือคำว่า "ราคารับซื้อ" ด้านบนสุด

  // ---------- ส่วนที่ 2: กล่องคำอธิบายด้านบน ----------
  static const double? headerTitleFontSize =
      null; // หัวข้อ "ตารางราคารับซื้อวัสดุรีไซเคิล"
  static const double? headerSubtitleFontSize =
      null; // คำอธิบายยาวๆ "แอปดึงรายการ..."

  // ---------- ส่วนที่ 3: แถวเวลาอัปเดต ----------
  static const double? lastUpdatedFontSize = null; // คำว่า "อัปเดตล่าสุด: ..."

  // ---------- ส่วนที่ 4: ปุ่มกดสีเขียว ----------
  static const double updateButtonHeight =
      58; // ความสูงของปุ่ม (ถ้าอาจารย์บอกปุ่มแคบไป ให้เพิ่มเลขนี้)
  static const double? updateButtonFontSize =
      20; // ตัวหนังสือในปุ่ม "อัปเดตราคาจากเว็บ"

  // ---------- ส่วนที่ 5: การ์ดแสดงราคาแต่ละรายการ ----------
  static const double cardIconSize = 28; // ขนาดของไอคอนรูปรถเข็น/รีไซเคิล
  static const double? cardTitleFontSize = 19; // ชื่อวัสดุ เช่น กระดาษ, พลาสติก
  static const double? cardSubtitleFontSize =
      15; // คำอธิบายเล็กๆ เช่น "หมวดหมู่ • วงษ์พาณิชย์"
  static const double? cardPriceFontSize =
      19; // ตัวเลขราคาด้านขวา (เช่น 3.80/กก.)
}

// ===========================================================================
// ชิ้นส่วนที่ 1: กล่องข้อความอธิบายด้านบนสุด (PriceHeaderCard)
// ===========================================================================
class PriceHeaderCard extends StatelessWidget {
  const PriceHeaderCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity, // สั่งให้กล่องกว้างเต็มจอ
      padding: const EdgeInsets.all(20), // ระยะห่างจากขอบกล่องถึงตัวหนังสือ
      decoration: BoxDecoration(
        color: AppColors.cardGreen, // สีพื้นหลังกล่อง
        borderRadius: BorderRadius.circular(28), // ขอบโค้งมน
        border: Border.all(color: AppColors.cardBorder), // เส้นขอบ
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // จัดให้ข้อความชิดซ้าย
        children: [
          // บรรทัดแรก: หัวข้อ
          Text(
            'ตารางราคารับซื้อวัสดุรีไซเคิล',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w900,
              color: AppColors.textDark,
              fontSize:
                  PriceStyle.headerTitleFontSize, // 📌 ดึงขนาดจาก PriceStyle
            ),
          ),
          const SizedBox(height: 8), // ระยะห่างระหว่างหัวข้อกับคำอธิบาย
          // บรรทัดสอง: คำอธิบาย
          Text(
            'แอปดึงรายการราคารับซื้อล่าสุดจากเว็บไซต์ร้านรับซื้อของเก่าวงษ์พาณิชย์ '
            'และบันทึกลง SQLite เพื่อใช้เป็นราคามาตรฐานทั่วทั้งแอป',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.textMuted,
              fontWeight: FontWeight.w500,
              fontSize:
                  PriceStyle.headerSubtitleFontSize, // 📌 ดึงขนาดจาก PriceStyle
            ),
          ),
        ],
      ),
    );
  }
}

// ===========================================================================
// ชิ้นส่วนที่ 2: แถวบอกเวลา "อัปเดตล่าสุด" (PriceLastUpdatedRow)
// ===========================================================================
class PriceLastUpdatedRow extends StatelessWidget {
  const PriceLastUpdatedRow({required this.lastUpdated, super.key});
  final DateTime? lastUpdated; // รับค่าเวลาล่าสุดมาจากหน้าหลัก

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(
          Icons.history_rounded,
          color: AppColors.darkGreen,
          size: 22,
        ), // ไอคอนนาฬิกา
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            // เช็คว่าถ้าไม่เคยอัปเดตให้ขึ้นว่า "ยังไม่มีการอัปเดต"
            lastUpdated == null
                ? 'ยังไม่มีการอัปเดต'
                : 'อัปเดตล่าสุด: ${DateFormatter.dateTime(lastUpdated!)}',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.textMuted,
              fontWeight: FontWeight.w600,
              fontSize:
                  PriceStyle.lastUpdatedFontSize, // 📌 ดึงขนาดจาก PriceStyle
            ),
          ),
        ),
      ],
    );
  }
}

// ===========================================================================
// ชิ้นส่วนที่ 3: ปุ่มกดอัปเดตราคาจากเว็บ (PriceUpdateButton)
// ===========================================================================
class PriceUpdateButton extends StatelessWidget {
  const PriceUpdateButton({
    required this.isUpdating, // ส่งสถานะมาว่ากำลังโหลดอยู่ไหม
    required this.onPressed, // ฟังก์ชันตอนถูกกด
    super.key,
  });

  final bool isUpdating;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      // ถ้ากำลังโหลด (isUpdating = true) จะสั่งให้ปุ่มกดไม่ได้ (null)
      onPressed: isUpdating ? null : onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.primaryGreen, // สีปุ่ม
        foregroundColor: Colors.white, // สีตัวหนังสือในปุ่ม
        minimumSize: Size.fromHeight(
          PriceStyle.updateButtonHeight,
        ), // 📌 ดึงความสูงจาก PriceStyle
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ), // ความโค้งปุ่ม
        textStyle: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w900,
          fontSize:
              PriceStyle.updateButtonFontSize, // 📌 ดึงขนาดฟอนต์จาก PriceStyle
        ),
      ),
      // เปลี่ยนไอคอน: ถ้าโหลดให้หมุนๆ ถ้าไม่โหลดเป็นรูปเมฆ
      icon: isUpdating
          ? const SizedBox(
              height: 20,
              width: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2.4,
                color: Colors.white,
              ),
            )
          : const Icon(Icons.cloud_download_rounded, size: 28),
      // เปลี่ยนคำพูดในปุ่ม
      label: Text(isUpdating ? 'กำลังอัปเดต...' : 'อัปเดตราคาจากเว็บ'),
    );
  }
}

// ===========================================================================
// ชิ้นส่วนที่ 4: แถบสีแดงแจ้งเตือนเวลา Error (PriceErrorBanner)
// ===========================================================================
class PriceErrorBanner extends StatelessWidget {
  const PriceErrorBanner({required this.message, super.key});
  final String message; // ข้อความ Error

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(
          context,
        ).colorScheme.errorContainer, // พื้นหลังสีแดงอ่อน
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: Theme.of(
              context,
            ).colorScheme.onErrorContainer, // ไอคอนสีแดงเข้ม
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message, // แสดงข้อความ
              style: TextStyle(
                color: Theme.of(context).colorScheme.onErrorContainer,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ===========================================================================
// ชิ้นส่วนที่ 5: การ์ดแสดงราคาสินค้าแต่ละชิ้น (PriceCard)
// ===========================================================================
class PriceCard extends StatelessWidget {
  const PriceCard({required this.price, super.key});
  final MaterialPriceModel price;

  @override
  Widget build(BuildContext context) {
    // เช็คว่าราคามาจากวงษ์พาณิชย์ หรือเป็นค่าเริ่มต้น
    final bool isLive = price.source == WongpanitPriceService.sourceName;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardGreen,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          // รูปไอคอนด้านซ้าย
          Container(
            height: 52,
            width: 52,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(
              Icons.recycling_rounded, // เปลี่ยนรูปไอคอนได้ตรงนี้
              color: AppColors.primaryGreen,
              size: PriceStyle.cardIconSize, // 📌 ดึงขนาดไอคอนจาก PriceStyle
            ),
          ),
          const SizedBox(width: 14),

          // ข้อความตรงกลาง (ชื่อและหมวดหมู่)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  price.displayName, // ชื่อวัสดุ (เช่น พลาสติก PET)
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: AppColors.textDark,
                    fontSize: PriceStyle
                        .cardTitleFontSize, // 📌 ดึงขนาดจาก PriceStyle
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${price.category} • ${isLive ? 'วงษ์พาณิชย์' : 'ค่าเริ่มต้น'}', // หมวดหมู่
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.textMuted,
                    fontWeight: FontWeight.w600,
                    fontSize: PriceStyle
                        .cardSubtitleFontSize, // 📌 ดึงขนาดจาก PriceStyle
                  ),
                ),
              ],
            ),
          ),

          // ข้อความด้านขวา (ราคา)
          Text(
            '${NumberFormatter.money(price.pricePerKg)}/กก.',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
              color: AppColors.primaryGreen,
              fontSize:
                  PriceStyle.cardPriceFontSize, // 📌 ดึงขนาดจาก PriceStyle
            ),
          ),
        ],
      ),
    );
  }
}
