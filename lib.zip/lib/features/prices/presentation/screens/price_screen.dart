import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/material_catalog.dart';
import '../../../../services/database/app_database.dart';
import '../../../../services/price_source/wongpanit_price_service.dart';
import '../../data/models/material_price_model.dart';
import '../../data/repositories/material_price_repository.dart';
import '../../data/services/price_update_service.dart';
import 'price_management_screen.dart';
import '../widgets/price_screen_widgets.dart';

// ===========================================================================
// หน้าจอหลัก (StatefulWidget) : ใช้ Stateful เพราะหน้าจอสามารถเปลี่ยนสถานะได้
// เช่น จาก "กำลังโหลด" เป็น "โหลดเสร็จแล้ว" หรือ "เกิด Error"
// ===========================================================================
class PriceScreen extends StatefulWidget {
  const PriceScreen({super.key});

  @override
  State<PriceScreen> createState() => _PriceScreenState();
}

class _PriceScreenState extends State<PriceScreen> {
  // ตัวจัดการฐานข้อมูลและการดึงราคาจากเว็บ (Scraping)
  late final MaterialPriceRepository _priceRepository;
  late final PriceUpdateService _priceUpdateService;

  // สถานะ (State) ของหน้าจอ
  List<MaterialPriceModel> _prices = []; // เก็บข้อมูลราคาทั้งหมด
  bool _isLoading = true; // หมุนโหลดตอนเปิดหน้าครั้งแรก
  bool _isUpdating = false; // หมุนโหลดตอนกดปุ่ม "อัปเดตราคาจากเว็บ"
  String? _errorMessage; // เก็บข้อความ Error สีแดง

  // ฟังก์ชันหาเวลา "อัปเดตล่าสุด" โดยเทียบเวลาทุกรายการแล้วเอาอันใหม่สุด
  DateTime? get _lastUpdated {
    if (_prices.isEmpty) return null;
    return _prices
        .map((price) => price.updatedAt)
        .reduce((a, b) => a.isAfter(b) ? a : b);
  }

  // initState ทำงานครั้งแรกครั้งเดียวตอนเปิดหน้านี้
  @override
  void initState() {
    super.initState();
    // 1. เตรียมเครื่องมือเชื่อมต่อ Database
    _priceRepository = MaterialPriceRepository(database: AppDatabase.instance);
    _priceUpdateService = PriceUpdateService(priceRepository: _priceRepository);

    // 2. สั่งโหลดราคามาแสดงบนจอทันที
    _loadPrices();
  }

  // ===========================================================================
  // ระบบหลังบ้าน: ฟังก์ชันจัดการข้อมูล
  // ===========================================================================

  /// โหลดรายการราคาจาก SQLite เพื่อแสดงบนหน้านี้
  Future<void> _loadPrices() async {
    // try-catch แยกกรณีอ่านราคาได้และกรณี Repository/SQLite ส่งข้อผิดพลาด
    try {
      // await รอรายการ MaterialPriceModel จาก Repository ก่อนอัปเดตหน้าจอ
      final prices = await _priceRepository.getAllPrices();

      // โค้ด if (!mounted) return; สำคัญมาก! ป้องกันแอปพังถ้าผู้ใช้กดออกหน้านี้ก่อนโหลดเสร็จ
      if (!mounted) return;

      // setState แจ้ง Flutter ให้แสดงรายการราคาชุดใหม่
      setState(() {
        _prices = prices; // เอาข้อมูลราคาใส่ตัวแปร
        _isLoading = false; // เลิกหมุนโหลด
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isLoading = false; // ถ้า Error ก็ต้องเลิกหมุน
      });
    }
  }

  /// เรียก service ดึงราคาเว็บ แล้วโหลดข้อมูล SQLite มาแสดงอีกครั้ง
  Future<void> _updatePrices() async {
    // ปิดปุ่มระหว่างอัปเดตและล้างข้อความผิดพลาดจากการลองครั้งก่อน
    setState(() {
      _isUpdating = true; // เริ่มหมุนในปุ่ม
      _errorMessage = null; // ล้างข้อความ Error เก่าออก
    });

    try {
      // ไปดึงจากเว็บ
      final result = await _priceUpdateService.updateFromWeb();
      // ดึงเสร็จ ให้ดึงข้อมูลจาก DB มาโชว์ใหม่
      await _loadPrices();

      if (!mounted) return;

      // โชว์ข้อความด้านล่าง (SnackBar) ว่าสำเร็จกี่รายการ
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'อัปเดตราคาแล้ว ${result.updatedCount}/${result.totalLabels} รายการจากเว็บ',
          ),
        ),
      );
    } on PriceFetchException catch (error) {
      // ถ้าเชื่อมต่อเว็บไม่ได้
      if (!mounted) return;
      setState(() {
        _errorMessage = error.message;
      });
    } catch (error) {
      // ถ้า Error แปลกๆ
      if (!mounted) return;
      setState(() {
        _errorMessage = 'เกิดข้อผิดพลาดขณะอัปเดตราคา';
      });
    } finally {
      // ไม่ว่าจะสำเร็จหรือพัง ก็ต้องเลิกหมุนในปุ่มเสมอ
      if (mounted) {
        setState(() {
          _isUpdating = false;
        });
      }
    }
  }

  /// เปิดหน้าจัดการราคา และโหลด SQLite ใหม่เมื่อกลับมาจากหน้านั้น
  Future<void> _openPriceManagement() async {
    // Navigator.push เปิด PriceManagementScreen; await รอจนผู้ใช้ย้อนกลับมา
    await Navigator.push(
      context,
      MaterialPageRoute<void>(builder: (_) => const PriceManagementScreen()),
    );
    // อัปเดตรายการหน้าเดิมให้ตรงกับราคาที่อาจแก้ในหน้าจัดการ
    await _loadPrices();
  }

  // ===========================================================================
  // โครงสร้างหน้าจอ (UI) ที่ผูกเอา Widget จากอีกไฟล์มาต่อกัน
  // ===========================================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background, // สีพื้นหลังหน้าแอป
      // แถบด้านบน
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0, // 0 = ไม่มีเงา
        title: Text(
          'ราคารับซื้อ',
          style: TextStyle(
            color: AppColors.textDark,
            fontWeight: FontWeight.w900,
            fontSize:
                PriceStyle.appBarTitleFontSize, // 📌 ดึงขนาดจาก PriceStyle
          ),
        ),
        iconTheme: const IconThemeData(color: AppColors.textDark),
      ),
      // ส่วนเนื้อหา
      body: SafeArea(
        // เลื่อนจอลงมาเพื่อรีเฟรชได้
        child: RefreshIndicator(
          onRefresh: _loadPrices,
          // ถ้า _isLoading เป็นจริง ให้โชว์ตัวหมุนตรงกลางจอ, ถ้าเป็นเท็จให้โชว์ ListView
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(
                    20,
                    8,
                    20,
                    28,
                  ), // ขอบซ้าย,บน,ขวา,ล่าง
                  children: [
                    // --- วางชิ้นส่วน Widget เรียงลงมา ---
                    const PriceHeaderCard(), // กล่องอธิบาย
                    const SizedBox(height: 18),

                    PriceLastUpdatedRow(lastUpdated: _lastUpdated), // แถวเวลา
                    const SizedBox(height: 14),

                    PriceUpdateButton(
                      isUpdating: _isUpdating,
                      onPressed: _updatePrices, // กดแล้วเรียกฟังก์ชันดึงเว็บ
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      // เปิดหน้าจัดการราคาแยกจากการอัปเดตราคาจากเว็บไซต์
                      onPressed: _openPriceManagement,
                      icon: const Icon(Icons.edit_rounded, size: 28),
                      label: const Text('จัดการราคา'),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primaryGreen,
                        foregroundColor: Colors.white,
                        minimumSize: Size.fromHeight(
                          PriceStyle.updateButtonHeight,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(22),
                        ),
                        textStyle: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(
                              fontWeight: FontWeight.w900,
                              fontSize: PriceStyle.updateButtonFontSize,
                            ),
                      ),
                    ),

                    // แสดงข้อผิดพลาดจากการดึงราคาจากเว็บไซต์ ถ้ามี
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 14),
                      PriceErrorBanner(message: _errorMessage!),
                    ],

                    const SizedBox(height: 26),

                    // --- วงลูปสร้างการ์ดราคา ---
                    // กรอง (.where) เอาเฉพาะหมวดหมู่ที่ isSellable (ตั้งค่าว่าให้ขายได้)
                    for (final price in _prices.where(
                      (price) => MaterialCatalog.lookup(price.label).isSellable,
                    )) ...[
                      PriceCard(price: price), // สร้างการ์ดทีละใบ
                      const SizedBox(height: 14), // ระยะห่างระหว่างการ์ด
                    ],
                  ],
                ),
        ),
      ),
    );
  }
}
