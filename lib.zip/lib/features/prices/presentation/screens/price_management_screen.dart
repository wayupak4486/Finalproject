import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/utils/number_formatter.dart';
import '../../../../services/database/app_database.dart';
import '../../data/models/material_price_model.dart';
import '../../data/repositories/material_price_repository.dart';
import '../widgets/price_screen_widgets.dart';

/// หน้าจออ่านและแก้ไขราคาวัสดุที่เก็บอยู่ใน SQLite
class PriceManagementScreen extends StatefulWidget {
  const PriceManagementScreen({super.key});

  // สร้าง State สำหรับเก็บรายการราคาและสถานะระหว่างโหลดหรือบันทึก
  @override
  State<PriceManagementScreen> createState() => _PriceManagementScreenState();
}

class _PriceManagementScreenState extends State<PriceManagementScreen> {
  // ใช้ Repository เดิมเพื่ออ่านและบันทึกราคา ไม่เปิดฐานข้อมูลซ้ำในหน้านี้
  late final MaterialPriceRepository _priceRepository;

  // ข้อมูลจาก SQLite และสถานะที่ใช้ควบคุมการแสดงผลของหน้า
  List<MaterialPriceModel> _prices = [];
  bool _isLoading = true;
  String? _errorMessage;
  String? _savingLabel;

  // initState ทำงานครั้งเดียวเมื่อหน้าเริ่มต้น จึงเตรียม Repository และโหลดราคา
  @override
  void initState() {
    super.initState();
    _priceRepository = MaterialPriceRepository(database: AppDatabase.instance);
    _loadPrices();
  }

  /// อ่านราคาทั้งหมดจาก Repository แล้วอัปเดตสถานะของหน้าจอ
  Future<bool> _loadPrices({bool showLoading = true}) async {
    // แสดงสถานะโหลดเมื่อเป็นการโหลดทั่วไป แต่ไม่ปิดรายการระหว่างโหลดหลังบันทึก
    if (showLoading && mounted) {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });
    }

    // await รอผล SQLite; try-catch แยกกรณีอ่านสำเร็จกับเกิดข้อผิดพลาด
    try {
      final prices = await _priceRepository.getAllPrices();
      // mounted ป้องกันการเรียก setState หลังผู้ใช้ออกจากหน้านี้แล้ว
      if (!mounted) return false;

      // setState แจ้ง Flutter ให้วาดหน้าจอใหม่ด้วยรายการล่าสุด
      setState(() {
        _prices = prices;
        _isLoading = false;
        _errorMessage = null;
      });
      return true;
    } catch (error) {
      if (!mounted) return false;

      // เก็บข้อผิดพลาดไว้แสดงในหน้าจอแทนการแสดงรายการเหมือนโหลดสำเร็จ
      setState(() {
        _isLoading = false;
        _errorMessage = 'โหลดราคาไม่สำเร็จ: $error';
      });
      return false;
    }
  }

  /// เปิดฟอร์มแก้ราคา และบันทึกค่าที่ผ่านการตรวจสอบกลับลง SQLite
  Future<void> _editPrice(MaterialPriceModel price) async {
    // Form ใช้ตรวจค่าก่อนส่งกลับ ส่วน updatedPrice เก็บค่าที่ผู้ใช้ยืนยันแล้ว
    final formKey = GlobalKey<FormState>();
    var updatedPrice = price.pricePerKg;

    // showDialog แสดงฟอร์ม; await รอจนผู้ใช้ยกเลิกหรือส่งราคากลับด้วย Navigator.pop
    final confirmedPrice = await showDialog<double>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('แก้ไขราคา${price.displayName}'),
        content: Form(
          key: formKey,
          child: TextFormField(
            initialValue: price.pricePerKg.toStringAsFixed(2),
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'ราคาต่อกิโลกรัม (บาท)',
              suffixText: 'บาท/กก.',
            ),
            validator: (value) {
              final parsed = double.tryParse(value?.trim() ?? '');
              // ปฏิเสธข้อความที่แปลงเป็นเลขไม่ได้ รวมถึงค่าอนันต์และ NaN
              if (parsed == null || !parsed.isFinite) {
                return 'กรุณากรอกราคาเป็นตัวเลขที่ถูกต้อง';
              }
              // ราคาไม่ควรติดลบ
              if (parsed < 0) {
                return 'ราคาต้องไม่ติดลบ';
              }
              return null;
            },
            onSaved: (value) {
              updatedPrice = double.parse(value!.trim());
            },
          ),
        ),
        actions: [
          // Navigator.pop โดยไม่ส่งค่า คือผู้ใช้ยกเลิกการแก้ไข
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('ยกเลิก'),
          ),
          FilledButton(
            onPressed: () {
              // validate ก่อน save; เมื่อผ่านแล้วส่งค่าราคากลับไปยัง _editPrice
              if (!formKey.currentState!.validate()) return;
              formKey.currentState!.save();
              Navigator.pop(dialogContext, updatedPrice);
            },
            child: const Text('บันทึก'),
          ),
        ],
      ),
    );

    // null หมายถึงผู้ใช้ยกเลิก และ mounted ป้องกันทำงานต่อเมื่อหน้าถูกปิด
    if (confirmedPrice == null || !mounted) return;

    // เก็บ label ที่กำลังบันทึกเพื่อแสดงสถานะและป้องกันการกดแก้หลายรายการพร้อมกัน
    setState(() {
      _savingLabel = price.label;
    });

    // บันทึกราคาที่แก้ผ่าน Repository เดิม แล้วอ่านรายการจาก SQLite ใหม่
    try {
      await _priceRepository.upsertPrice(
        label: price.label,
        pricePerKg: confirmedPrice,
        // ระบุว่าราคานี้ถูกแก้ด้วยตนเอง พร้อมเวลาที่บันทึกล่าสุด
        source: 'manual',
        updatedAt: DateTime.now(),
      );

      // โหลดข้อมูลใหม่โดยไม่แสดง loading เต็มหน้า
      final reloaded = await _loadPrices(showLoading: false);
      if (!mounted) return;

      // แจ้งผลสำเร็จ หรือแจ้งกรณีบันทึกได้แต่โหลดรายการใหม่ไม่สำเร็จ
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            reloaded
                ? 'บันทึกราคา${price.displayName}แล้ว'
                : 'บันทึกราคาแล้ว แต่โหลดรายการใหม่ไม่สำเร็จ',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;

      // แสดงข้อผิดพลาดจากการบันทึกให้ผู้ใช้ทราบ
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('บันทึกราคาไม่สำเร็จ: $error')));
    } finally {
      // คืนสถานะปุ่มแก้ไขไม่ว่าจะบันทึกสำเร็จหรือเกิดข้อผิดพลาด
      if (mounted) {
        setState(() {
          _savingLabel = null;
        });
      }
    }
  }

  // วาดหน้า AppBar และเลือกแสดง loading, error, empty state หรือรายการราคา
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        title: Text(
          'จัดการราคา',
          style: TextStyle(
            color: AppColors.textDark,
            fontWeight: FontWeight.w900,
            fontSize: PriceStyle.appBarTitleFontSize,
          ),
        ),
        iconTheme: const IconThemeData(color: AppColors.textDark),
      ),
      body: SafeArea(
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _errorMessage != null
            ? _buildErrorView()
            : RefreshIndicator(
                onRefresh: _loadPrices,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
                  children: [
                    _buildHeaderCard(context),
                    const SizedBox(height: 18),
                    //_buildReloadButton(context),
                    const SizedBox(height: 22),
                    if (_prices.isEmpty)
                      _buildEmptyState(context)
                    else
                      for (final price in _prices) ...[
                        _buildPriceCard(context, price),
                        const SizedBox(height: 14),
                      ],
                  ],
                ),
              ),
      ),
    );
  }

  // แนะนำหน้าที่และแจ้งว่าราคาที่จัดการถูกเก็บใน SQLite
  Widget _buildHeaderCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cardGreen,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'จัดการราคารับซื้อวัสดุรีไซเคิล',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w900,
              color: AppColors.textDark,
              fontSize: PriceStyle.headerTitleFontSize,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'แก้ไขราคามาตรฐานที่จัดเก็บใน SQLite '
            'เพื่อใช้ในการประเมินมูลค่าวัสดุ',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.textMuted,
              fontWeight: FontWeight.w500,
              fontSize: PriceStyle.headerSubtitleFontSize,
            ),
          ),
        ],
      ),
    );
  }

  // ปุ่มนี้อ่านราคาจากฐานข้อมูลใหม่ ไม่ได้เรียกการอัปเดตราคาจากเว็บไซต์
  /*Widget _buildReloadButton(BuildContext context) {
    return FilledButton.icon(
      onPressed: _isLoading || _savingLabel != null ? null : _loadPrices,
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        minimumSize: Size.fromHeight(PriceStyle.updateButtonHeight),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        textStyle: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w900,
          fontSize: PriceStyle.updateButtonFontSize,
        ),
      ),
      icon: const Icon(Icons.refresh_rounded, size: 28),
      label: const Text('โหลดราคาล่าสุด'),
    );
  }*/

  // แสดงข้อมูลวัสดุหนึ่งรายการ และเรียก _editPrice เมื่อกดไอคอนแก้ไข
  Widget _buildPriceCard(BuildContext context, MaterialPriceModel price) {
    final isSaving = _savingLabel == price.label;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardGreen,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          Container(
            height: 52,
            width: 52,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(
              Icons.recycling_rounded,
              color: AppColors.primaryGreen,
              size: PriceStyle.cardIconSize,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  price.displayName,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: AppColors.textDark,
                    fontSize: PriceStyle.cardTitleFontSize,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  price.category,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.textMuted,
                    fontWeight: FontWeight.w600,
                    fontSize: PriceStyle.cardSubtitleFontSize,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${NumberFormatter.money(price.pricePerKg)}/กก.',
                textAlign: TextAlign.right,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: AppColors.primaryGreen,
                  fontSize: PriceStyle.cardPriceFontSize,
                ),
              ),
              SizedBox(
                height: 40,
                child: isSaving
                    ? const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : IconButton(
                        tooltip: 'แก้ไขราคา',
                        visualDensity: VisualDensity.compact,
                        onPressed: _savingLabel == null
                            ? () => _editPrice(price)
                            : null,
                        icon: const Icon(Icons.edit_rounded),
                        color: AppColors.primaryGreen,
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // แสดงข้อความเมื่ออ่านข้อมูลสำเร็จแต่ไม่มีรายการราคา
  Widget _buildEmptyState(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.cardGreen,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Text(
        'ยังไม่มีข้อมูลราคา',
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
          color: AppColors.textMuted,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  // แสดงข้อผิดพลาดจากการอ่าน พร้อมปุ่มให้ลองโหลดใหม่
  Widget _buildErrorView() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
      children: [
        PriceErrorBanner(message: _errorMessage!),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: _loadPrices,
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.primaryGreen,
            foregroundColor: Colors.white,
            minimumSize: Size.fromHeight(PriceStyle.updateButtonHeight),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
            ),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: PriceStyle.updateButtonFontSize,
            ),
          ),
          icon: const Icon(Icons.refresh_rounded, size: 28),
          label: const Text('ลองอีกครั้ง'),
        ),
      ],
    );
  }
}
