import '../../../../core/constants/database_constants.dart';
import '../../../../services/database/app_database.dart';
import '../models/material_price_model.dart';

/// รวมคำสั่งอ่านและเขียนข้อมูลราคาวัสดุผ่านฐานข้อมูลของแอป
class MaterialPriceRepository {
  MaterialPriceRepository({required this.database});

  // รับ AppDatabase instance เดิมจากหน้าจอหรือ service ที่เรียกใช้งาน
  final AppDatabase database;

  /// อ่านราคาทุกแถวจาก material_prices และเรียงตามชื่อที่แสดง
  Future<List<MaterialPriceModel>> getAllPrices() async {
    // await ขอ handle ฐานข้อมูลที่ AppDatabase เปิดหรือสร้างไว้
    final db = await database.database;

    // query อ่านข้อมูลตารางเดิม แล้วแปลงแต่ละแถวเป็น MaterialPriceModel
    final maps = await db.query(
      DatabaseConstants.materialPricesTable,
      orderBy: 'display_name ASC',
    );

    return maps.map(MaterialPriceModel.fromMap).toList();
  }

  /// คืน map ที่ใช้ label เป็นกุญแจและราคาเป็นค่า สำหรับหน้า Scan
  Future<Map<String, double>> getPricesByLabel() async {
    // ใช้รายการที่อ่านจาก SQLite แล้วแปลงให้ง่ายต่อการค้นหาราคาด้วย label
    final prices = await getAllPrices();

    return {for (final price in prices) price.label: price.pricePerKg};
  }

  /// อัปเดตราคา แหล่งที่มา และเวลา โดยค้นหาแถวจาก label
  ///
  /// เมธอดนี้ใช้ UPDATE ตาม label ที่มีอยู่ ไม่ได้ INSERT แถวใหม่
  Future<void> upsertPrice({
    required String label,
    required double pricePerKg,
    required String source,
    required DateTime updatedAt,
  }) async {
    final db = await database.database;

    // whereArgs ส่ง label แยกจาก SQL เพื่อจับคู่แถววัสดุที่ต้องการแก้
    await db.update(
      DatabaseConstants.materialPricesTable,
      {
        'price_per_kg': pricePerKg,
        'source': source,
        'updated_at': updatedAt.toIso8601String(),
      },
      where: 'label = ?',
      whereArgs: [label],
    );
  }
}
