import 'dart:async';
import 'package:flutter/material.dart';

class CustomSplashScreen extends StatefulWidget {
  const CustomSplashScreen({super.key});

  @override
  State<CustomSplashScreen> createState() => _CustomSplashScreenState();
}

class _CustomSplashScreenState extends State<CustomSplashScreen> {
  @override
  void initState() {
    super.initState();
    // หน่วงเวลา 2 วินาที แล้วเปิดไปยังหน้าหลักของแอป
    Timer(const Duration(seconds: 2), () {
      // TODO: เปลี่ยนไปหน้าแรกของคุณ เช่น Navigator.pushReplacement(...)
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset(
          'assets/images/logo.png',
          width: 280, // <-- สามารถปรับขนาดความกว้างได้ตามใจชอบตรงนี้
          height: 280,
        ),
      ),
    );
  }
}
