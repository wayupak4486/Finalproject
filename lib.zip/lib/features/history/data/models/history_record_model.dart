class HistoryRecordModel {
  const HistoryRecordModel({
    this.id,
    required this.imagePath,
    required this.material,
    required this.category,
    required this.confidence,
    required this.weight,
    required this.pricePerKg,
    required this.estimatedPrice,
    required this.co2Saved,
    required this.co2FactorPerKg,
    required this.pointsEarned,
    required this.note,
    required this.createdAt,
  });

  final int? id;
  final String imagePath;
  final String material;
  final String category;
  final double confidence;
  final double weight;
  final double pricePerKg;
  final double estimatedPrice;
  final double co2Saved;
  final double co2FactorPerKg;
  final int pointsEarned;
  final String? note;
  final DateTime createdAt;

  /// True when this record was saved without a weight and is still waiting
  /// for the user to fill it in from the history list. Non-sellable
  /// materials (price_per_kg of 0) never show a weight field on the result
  /// screen, so they are excluded here even though their weight is 0.
  bool get isPendingWeight => weight <= 0 && pricePerKg > 0;

  /// Only exposes the fields that change when the user fills in a pending
  /// weight later (see [HistoryScreen._confirmWeight]) — everything else on
  /// a saved record (material, price per kg, note, ...) never changes after
  /// the fact, so there is no parameter for it here.
  HistoryRecordModel copyWith({
    double? weight,
    double? estimatedPrice,
    double? co2Saved,
    int? pointsEarned,
  }) {
    return HistoryRecordModel(
      id: id,
      imagePath: imagePath,
      material: material,
      category: category,
      confidence: confidence,
      weight: weight ?? this.weight,
      pricePerKg: pricePerKg,
      estimatedPrice: estimatedPrice ?? this.estimatedPrice,
      co2Saved: co2Saved ?? this.co2Saved,
      co2FactorPerKg: co2FactorPerKg,
      pointsEarned: pointsEarned ?? this.pointsEarned,
      note: note,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'image_path': imagePath,
      'material': material,
      'category': category,
      'confidence': confidence,
      'weight': weight,
      'price_per_kg': pricePerKg,
      'estimated_price': estimatedPrice,
      'co2_saved': co2Saved,
      'co2_factor_per_kg': co2FactorPerKg,
      'points_earned': pointsEarned,
      'note': note,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory HistoryRecordModel.fromMap(Map<String, dynamic> map) {
    return HistoryRecordModel(
      id: map['id'] as int?,
      imagePath: map['image_path'] as String,
      material: map['material'] as String,
      category: map['category'] as String,
      confidence: (map['confidence'] as num).toDouble(),
      weight: (map['weight'] as num).toDouble(),
      pricePerKg: (map['price_per_kg'] as num).toDouble(),
      estimatedPrice: (map['estimated_price'] as num).toDouble(),
      co2Saved: (map['co2_saved'] as num).toDouble(),
      co2FactorPerKg: (map['co2_factor_per_kg'] as num?)?.toDouble() ?? 0,
      pointsEarned: map['points_earned'] as int,
      note: map['note'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}

/// Aggregate totals shared by the home and statistics screens.
extension HistoryRecordListSummary on List<HistoryRecordModel> {
  double get totalEstimatedPrice =>
      fold<double>(0, (sum, record) => sum + record.estimatedPrice);

  double get totalCo2Saved =>
      fold<double>(0, (sum, record) => sum + record.co2Saved);

  int get totalPointsEarned =>
      fold<int>(0, (sum, record) => sum + record.pointsEarned);
}
