import '../../../../services/ml/classification_result.dart';

class ScanResultArgs {
  const ScanResultArgs({required this.imagePath, required this.result});

  // 🔧 [แก้ตรงนี้] เดิมเขียนว่า  final String imagePath;
  // เติมเครื่องหมาย ? ต่อท้าย String เพื่อบอกว่า "ค่านี้เป็น null (ไม่มีรูป) ได้"
  // กรณีเลือกวัสดุเอง ไม่มีรูปถ่าย จึงส่ง null มาได้โดยไม่แดง
  final String? imagePath;

  final ClassificationResult result; // ผลลัพธ์จาก AI (หรือผลจำลองกรณีเลือกเอง)
}