import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

/// Debug-only utility for inspecting the app's SQLite database contents.
///
/// Every method is a no-op outside of debug builds, so it is safe to call
/// unconditionally from production code paths.
class DatabaseDebugTool {
  const DatabaseDebugTool._();

  static void logLocation({required String name, required String path}) {
    if (!kDebugMode) return;

    debugPrint('[DatabaseDebugTool] name: $name');
    debugPrint('[DatabaseDebugTool] path: $path');
  }

  /// Names of every user table (internal `sqlite_*` tables excluded).
  static Future<List<String>> listTables(Database db) async {
    final tables = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table'",
    );
    return tables
        .map((row) => row['name'] as String)
        .where((name) => !name.startsWith('sqlite_'))
        .toList();
  }

  static Future<int> countRows(Database db, String tableName) async {
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM $tableName',
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  static Future<List<Map<String, Object?>>> fetchRows(
    Database db,
    String tableName,
  ) {
    return db.query(tableName);
  }

  /// Dumps every table's row count and contents to the console.
  static Future<void> dumpAllTables(Database db) async {
    if (!kDebugMode) return;

    try {
      final tableNames = await listTables(db);

      debugPrint('[DatabaseDebugTool] === DEBUG DUMP START ===');
      debugPrint(
        '[DatabaseDebugTool] Tables (${tableNames.length}): $tableNames',
      );

      for (final tableName in tableNames) {
        final count = await countRows(db, tableName);
        debugPrint('[DatabaseDebugTool] Table "$tableName": $count row(s)');

        final rows = await fetchRows(db, tableName);
        for (var i = 0; i < rows.length; i++) {
          debugPrint('[DatabaseDebugTool]   [$tableName][$i] ${rows[i]}');
        }
      }

      debugPrint('[DatabaseDebugTool] === DEBUG DUMP END ===');
    } catch (e, stackTrace) {
      debugPrint('[DatabaseDebugTool] dumpAllTables() failed: $e');
      debugPrint('[DatabaseDebugTool] $stackTrace');
    }
  }
}
