import 'package:flutter/material.dart';

import 'app_database.dart';
import 'database_debug_tool.dart';

/// Debug-only screen that lists every table in the local SQLite database
/// and lets you drill into its rows. Only meant to be reachable from a
/// kDebugMode-gated entry point (see SettingsScreen).
class DatabaseDebugScreen extends StatefulWidget {
  const DatabaseDebugScreen({super.key});

  @override
  State<DatabaseDebugScreen> createState() => _DatabaseDebugScreenState();
}

class _DatabaseDebugScreenState extends State<DatabaseDebugScreen> {
  late Future<List<String>> _tablesFuture;

  @override
  void initState() {
    super.initState();
    _tablesFuture = _loadTables();
  }

  Future<List<String>> _loadTables() async {
    final db = await AppDatabase.instance.database;
    return DatabaseDebugTool.listTables(db);
  }

  void _reload() {
    setState(() {
      _tablesFuture = _loadTables();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Database Debug Viewer'),
        actions: [
          IconButton(
            onPressed: _reload,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: FutureBuilder<List<String>>(
        future: _tablesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('โหลดตารางไม่สำเร็จ: ${snapshot.error}'));
          }

          final tables = snapshot.data ?? [];
          if (tables.isEmpty) {
            return const Center(child: Text('ไม่พบตารางในฐานข้อมูล'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: tables.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              return _TableSection(tableName: tables[index]);
            },
          );
        },
      ),
    );
  }
}

class _TableSection extends StatefulWidget {
  const _TableSection({required this.tableName});

  final String tableName;

  @override
  State<_TableSection> createState() => _TableSectionState();
}

class _TableSectionState extends State<_TableSection> {
  late final Future<int> _countFuture;
  Future<List<Map<String, Object?>>>? _rowsFuture;

  @override
  void initState() {
    super.initState();
    _countFuture = _loadCount();
  }

  Future<int> _loadCount() async {
    final db = await AppDatabase.instance.database;
    return DatabaseDebugTool.countRows(db, widget.tableName);
  }

  Future<List<Map<String, Object?>>> _loadRows() async {
    final db = await AppDatabase.instance.database;
    return DatabaseDebugTool.fetchRows(db, widget.tableName);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        title: Text(widget.tableName),
        subtitle: FutureBuilder<int>(
          future: _countFuture,
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Text('กำลังนับแถว...');
            return Text('${snapshot.data} แถว');
          },
        ),
        onExpansionChanged: (expanded) {
          if (expanded && _rowsFuture == null) {
            setState(() {
              _rowsFuture = _loadRows();
            });
          }
        },
        children: [
          if (_rowsFuture != null)
            FutureBuilder<List<Map<String, Object?>>>(
              future: _rowsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.all(16),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }

                if (snapshot.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('โหลดข้อมูลไม่สำเร็จ: ${snapshot.error}'),
                  );
                }

                final rows = snapshot.data ?? [];
                if (rows.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('ตารางว่าง'),
                  );
                }

                final columns = rows.first.keys.toList();

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  child: DataTable(
                    columns: [
                      for (final column in columns)
                        DataColumn(label: Text(column)),
                    ],
                    rows: [
                      for (final row in rows)
                        DataRow(
                          cells: [
                            for (final column in columns)
                              DataCell(Text('${row[column]}')),
                          ],
                        ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}
